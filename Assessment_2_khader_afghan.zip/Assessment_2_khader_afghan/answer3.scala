

object answer3  
{
	//Main Method
	def main(args: Array[String])
	{	
            import scala.io.StdIn._
    val name = readLine("Enter your name: ")
    print("Enter your age: ")
    val age = readInt()
    print(Console.UNDERLINED)

    println(Console.BOLD)
    print("Name: ")
    print(name)
    println(Console.BOLD)
    print("Age: ")
    print(Console.RESET)
    print(age)
		     
	}
}