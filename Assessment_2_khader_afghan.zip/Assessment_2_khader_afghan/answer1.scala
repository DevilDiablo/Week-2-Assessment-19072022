
object answer1
{
	//Main Method
	def main(args: Array[String])
	{	
		val str = "https://www.google.com"
		val revToUpperCase = str.reverse.toUpperCase()
		println(revToUpperCase)
	}
}