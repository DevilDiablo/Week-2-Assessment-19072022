
import scala.io.StdIn._
object answer5
{
	//Main Method
	def main(args: Array[String])
	{	
    val favoriteMovie = readLine("What is your favorite movie of all times? ")
    println(s"$favoriteMovie is totally awesome!")
	}
}